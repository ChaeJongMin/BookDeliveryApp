package com.example.reigster_show

data class Book(var name : String? = null, var publisher : String? = null)