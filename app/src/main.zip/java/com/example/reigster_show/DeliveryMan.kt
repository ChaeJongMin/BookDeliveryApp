package com.example.reigster_show

class DeliveryMan {
        var id: String=""
        var passwd: String=""
        var name: String=""
}