package com.example.reigster_show

import android.content.ContentValues
import android.util.Log
import com.google.android.gms.maps.model.LatLng
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class GetTimeAndMeter {
    fun requsetInfo(startPoint:LatLng, endPoint:LatLng){
        val dmUrl="https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&mode=transit&origins="+startPoint.latitude+","+startPoint.longitude+
                    "&destinations="+endPoint.latitude+","+endPoint.longitude+"&region=KR&key=AIzaSyAhvrVPyPIdmi7BWpvJIMO0s1q6rIhp6-o"
        Log.d("가져온 값", dmUrl)
        var result: String = ""
        val values: ContentValues? = null
        val relayTmapAPI = RelayTmapAPI()
        result=relayTmapAPI.request(dmUrl, values).toString()
        Log.d("가져온 값", result)
        val root = JSONObject(result)
        val rootarray=root.getJSONArray("rows")
        Log.d("가져온 값", rootarray.toString())
    }
}