package com.example.reigster_show
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.tabs.TabLayoutMediator
import com.example.reigster_show.databinding.ActivityTabmenuBinding

class TabMenu : AppCompatActivity() {
    val binding by lazy { ActivityTabmenuBinding.inflate(layoutInflater) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val list=listOf(RentalList(),RentalList(),RentalList())
        val pagerAdapter=FragmentPagerAdapter(list,this)
        binding.viewpager.adapter=pagerAdapter
        val titles= listOf("A","B","C")
        TabLayoutMediator(binding.tabLayout,binding.viewpager){tab,position->
            tab.text= titles.get(position)
        }.attach()
    }
}

class FragmentPagerAdapter(val fragmentList:List<Fragment>,fragmentActivity: FragmentActivity):FragmentStateAdapter(fragmentActivity){
    override fun getItemCount(): Int {
        return  fragmentList.size
    }

    override fun createFragment(position: Int): Fragment {
        return fragmentList.get(position)
    }
}