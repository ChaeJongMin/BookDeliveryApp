package com.example.reigster_show

class Customer{
    var id: String=""
    var passwd: String=""
    var name: String=""
    var address: String=""
    var phone: String=""
    var selectLib: String=""
}
